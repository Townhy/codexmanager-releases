param(
    [switch]$Lan,
    [switch]$Local
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$port = if ($env:PORT) { [int]$env:PORT } else { 6688 }

function Get-ListenerProcessIds([int]$LocalPort) {
    try {
        return @(Get-NetTCPConnection -LocalPort $LocalPort -State Listen -ErrorAction Stop | Select-Object -ExpandProperty OwningProcess -Unique)
    } catch {
        return @(netstat -ano -p tcp | ForEach-Object {
            if ($_ -match "^\s*TCP\s+\S+:$LocalPort\s+\S+\s+LISTENING\s+(\d+)\s*$") { [int]$Matches[1] }
        } | Select-Object -Unique)
    }
}

$existing = @(Get-ListenerProcessIds $port)
if ($existing.Count -gt 0) {
    Write-Output "Codex Web Manager is already running at http://127.0.0.1:$port"
    exit 0
}

$previousHost = $env:HOST
if ($Lan) { $env:HOST = "0.0.0.0" }
elseif ($Local) { $env:HOST = "127.0.0.1" }
try {
    $process = Start-Process -FilePath "node" `
        -ArgumentList "server/index.js" `
        -WorkingDirectory $root `
        -WindowStyle Hidden `
        -RedirectStandardOutput (Join-Path $root "server.stdout.log") `
        -RedirectStandardError (Join-Path $root "server.stderr.log") `
        -PassThru
} finally {
    $env:HOST = $previousHost
}

$ready = $false
for ($attempt = 0; $attempt -lt 40; $attempt++) {
    Start-Sleep -Milliseconds 250
    if ($process.HasExited) { break }
    try {
        $health = Invoke-RestMethod "http://127.0.0.1:$port/api/health" -TimeoutSec 2
        if ($health.ok) { $ready = $true; break }
    } catch { }
}

if (!$ready) {
    $stderr = Get-Content -Raw (Join-Path $root "server.stderr.log") -ErrorAction SilentlyContinue
    throw "Codex Web Manager failed to start. $stderr"
}

Write-Output "Codex Web Manager $($health.version) started at http://127.0.0.1:$port"
