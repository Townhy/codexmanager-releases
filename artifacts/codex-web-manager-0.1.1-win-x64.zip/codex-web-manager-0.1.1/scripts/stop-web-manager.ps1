$ErrorActionPreference = "Stop"
$port = if ($env:PORT) { [int]$env:PORT } else { 6688 }

function Get-ListenerProcessIds([int]$LocalPort) {
    try {
        return @(Get-NetTCPConnection -LocalPort $LocalPort -State Listen -ErrorAction Stop | Select-Object -ExpandProperty OwningProcess -Unique)
    } catch {
        return @(netstat -ano -p tcp | ForEach-Object {
            if ($_ -match "^\s*TCP\s+\S+:$LocalPort\s+\S+\s+LISTENING\s+(\d+)\s*$") { [int]$Matches[1] }
        } | Select-Object -Unique)
    }
}

$processIds = @(Get-ListenerProcessIds $port)
foreach ($processId in $processIds) {
    Stop-Process -Id $processId -Force -ErrorAction Stop
}

Start-Sleep -Milliseconds 300
$remaining = @(Get-ListenerProcessIds $port)
if ($remaining.Count -gt 0) { throw "Codex Web Manager did not stop; port $port is still owned by PID $($remaining -join ', ')." }
Write-Output "Codex Web Manager stopped; port $port is free"
