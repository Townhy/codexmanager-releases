$ErrorActionPreference = "Stop"
$startup = [Environment]::GetFolderPath("Startup")
$root = Split-Path -Parent $PSScriptRoot
$shortcutPath = Join-Path $startup "Codex Web Manager.lnk"
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = "powershell.exe"
$shortcut.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$(Join-Path $root 'scripts\start-web-manager.ps1')`""
$shortcut.WorkingDirectory = $root
$shortcut.WindowStyle = 7
$shortcut.Save()
Write-Output "Startup shortcut installed: $shortcutPath"
