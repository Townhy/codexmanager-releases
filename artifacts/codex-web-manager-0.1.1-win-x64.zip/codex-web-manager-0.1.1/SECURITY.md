# Security

`data/`, `.env`, logs, Codex homes, account exports, session databases and rollout files are local runtime data. They must never be committed or attached to a release.

Before every push or release, run:

```powershell
npm run security:check
```

If a credential was ever committed or uploaded, deleting the file in a later commit is not sufficient. Revoke or rotate every exposed API key and OAuth session, then remove the secret from Git history before making the repository public.

Do not expose the console directly to the public internet. Use a trusted LAN or VPN. `CODEX_WEB_MANAGER_TOKEN` is only suitable for API clients until the browser UI has a token login screen.
