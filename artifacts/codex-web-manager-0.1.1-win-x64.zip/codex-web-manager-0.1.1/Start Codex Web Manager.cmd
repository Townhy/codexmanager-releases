@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\setup.ps1" -Lan
if errorlevel 1 (
  echo.
  echo Codex Web Manager failed to start.
  pause
  exit /b 1
)
start "" "http://127.0.0.1:6688"
