# Codex Web Manager

面向移动办公的本地 Web 控制台，用独立 `CODEX_HOME` 管理多个 Codex Desktop Profile，并聚合所有本地会话。运行在安装 Codex Desktop 的电脑上后，可以通过手机或其他浏览器在可信局域网/VPN 中远程查看会话状态、继续对话、切换模型和管理账号。

项目目标是让个人多账号、高频使用 Codex 时不再局限于单个桌面应用窗口。它不是公网 SaaS，不应直接暴露到互联网。

当前稳定版本：[v0.1.5](https://github.com/Townhy/codexmanager/releases/tag/v0.1.5)

## 主要功能

- 聚合多个 `CODEX_HOME` 的本地会话，按项目分组、搜索并显示实时状态。
- 在电脑或手机浏览器中继续本地会话、切换模型并查看流式回复。
- 每个会话可选择“跟随 Profile”“工作区可写”或“完全访问”。
- 网页发起的任务支持停止；刷新页面、重新进入会话或换设备后仍可控制。
- 长会话默认加载最近 300 条消息，可继续加载更早记录并保持滚动位置。
- 使用 SSE 推送会话状态、消息变化和前端版本，更新后浏览器自动刷新。
- 管理独立 Profile，识别当前账号和进程，可选导入 Cockpit Tools 账号。
- 针对手机端优化会话列表、对话输入、底部导航和长会话渲染性能。

## 本地数据边界

这个工具会在本机保存信息，但不会主动上传这些信息：

- `data/config.json`：Profile 名称、本机路径、Cockpit 账号引用和控制台配置。
- `data/profiles/`：导入账号的 API Key 或 OAuth token，以及该 Profile 后续产生的 Codex 数据。
- Codex 原始目录：控制台直接读取各 Profile 的 SQLite、session index 和 rollout JSONL。
- `*.log`：本地服务输出。

以上内容全部被 `.gitignore` 排除，不会进入正常的 Git 提交或 Release ZIP。不要使用 `git add -f data`，也不要手工把凭据复制到源码、README、Issue 或 Release。

## 环境要求

- Windows 10/11
- Node.js 22.5 或更高版本
- 已安装 Codex Desktop
- Cockpit Tools 完全可选；只有使用账号导入功能时才需要本机已有 Cockpit 数据

启动 Desktop、发现 Windows 进程和停止任务使用了 Windows API，因此完整功能不适合部署在 Linux 容器中。远程使用建议将服务运行在安装 Codex Desktop 的 Windows 主机，再通过局域网、Tailscale 或其他可信 VPN 访问。

## 下载版首次使用

其他人不需要你的 `data/`，也不会拿到你的账号。下载 GitHub Release 中的 `codex-web-manager-<version>-win-x64.zip`，解压后双击：

```text
Start Codex Web Manager.cmd
```

启动后浏览器会自动打开，首次设置、Cockpit Tools 检测和账号导入都在网页中完成。命令行启动方式为：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/setup.ps1
```

脚本会检查 Node.js、创建本机 `.env` 和 `data/`、识别当前用户的 `%USERPROFILE%\.codex`，然后启动服务。浏览器打开 `http://127.0.0.1:6688`。

需要手机通过同一局域网访问时，首次运行改为：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/setup.ps1 -Lan
```

然后在“账号”页面查看局域网地址。只应在可信局域网或 VPN 中使用。

首次进入后：

1. 默认 Profile 自动指向这个用户自己的 `%USERPROFILE%\.codex`，已有 Codex 会话会直接出现。
2. 如果本机安装了 Cockpit Tools，可以在“账号”页面导入这个用户自己的 Cockpit 账号。
3. 没有 Cockpit Tools 时，可以手工新增 Profile，填写独立的 `CODEX_HOME` 和可选的 Desktop 启动路径。
4. 每个新环境都会生成独立 `data/`，不会从发布包继承作者的账号、路径或会话。

## 源码启动

```powershell
npm ci
npm run build
npm run setup
```

默认监听 `http://127.0.0.1:6688`。需要局域网访问时，在 `.env` 中设置 `HOST=0.0.0.0`，或运行：

```powershell
npm run start:lan
npm run stop
```

需要随 Windows 登录自动启动：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/install-startup.ps1
```

## 配置

本地配置放在不会提交的 `.env` 中。可用变量见 `.env.example`：

- `HOST`、`PORT`：监听地址和端口。
- `CODEX_WEB_MANAGER_TOKEN`：仅供能发送自定义请求头的 API 客户端使用。当前浏览器 UI 没有令牌登录页面，不要在普通网页部署中启用。
- `CODEX_WEB_MANAGER_DATA_DIR`：运行数据目录，默认 `./data`。
- `CODEX_COCKPIT_ROOT`：Cockpit Tools 数据目录覆盖。
- `CODEX_DESKTOP_CLI`：`codex.exe` 路径覆盖。
- `CODEX_DESKTOP_LAUNCH_PATH`：Codex Desktop 可执行文件路径覆盖。

不要把端口直接映射到公网。当前 UI 不提供互联网级身份认证、限流和 CSRF 防护；跨网络访问应使用 Tailscale 等可信 VPN。

## 对话交互边界

- 对话顶部可以选择模型和权限。选择结果用于下一条由网页发起的消息；运行中的轮次会锁定这些选项。
- “工作区可写”允许修改当前项目目录；“完全访问”会绕过 Codex 审批和沙箱，只应在可信会话中使用。
- 权限选择按会话保存在当前浏览器中，不会修改该 Profile 的全局 `config.toml`。
- 网页发起的任务可以停止，服务端会按会话查找活动 turn，不依赖当前页面保存的 Job ID。
- Codex Desktop 发起的活动轮次可从网页强制停止：服务端只终止目标 Profile 的 Desktop app-server 子进程，不关闭 Desktop 主窗口；该操作会同时中断该 Profile 中正在执行的其他 Desktop turn。
- 没有完成事件且超过 5 分钟未继续写入的 rollout 会显示为“已中断”，不会永久停留在“处理中”。
- 长会话首次返回最近 300 条消息，点击“加载更早消息”可按批次继续读取。
- 当前网页执行器使用 Codex app-server 的 `thread/resume` 和 `turn/start`，每个 Profile 使用独立 `CODEX_HOME` 和持久协议连接。
- 网页发起的活动轮次支持 `turn/steer` 追加引导和 `turn/interrupt` 精确停止；运行时输入框会同时显示追加引导和停止操作。
- Codex Desktop 当前通过私有 stdio 连接自己的 app-server，没有公开可附加的控制 socket。网页从独立 CLI 写入的消息会落到同一份会话文件，但 Desktop 已打开的页面不会实时刷新，需要重新打开该会话。
- SSE 会同步文件、状态和前端版本变化；MQTT 也无法改变 Desktop 内部 app-server 不接收外部事件这一事实。

若要求 Desktop 和网页同时实时显示、同时追加引导，需要上游提供共享 daemon/socket，或让两个 UI 都连接同一个由本工具管理的 app-server。直接注入 Electron 私有 IPC 或使用桌面点击自动化不适合作为稳定的多账号方案。

## 放入 Git

首次创建仓库前先运行安全检查：

```powershell
git init
npm run security:check
git add .
git status
git commit -m "Initial release"
```

使用 GitHub CLI 创建私有仓库：

```powershell
gh repo create codex-web-manager --private --source . --remote origin --push
```

建议先保持私有。确认 `git status --ignored` 中 `data/`、`.env` 和日志均显示为 ignored 后，再考虑公开源码。

## 版本发布

本地生成 Windows 发布包：

```powershell
npm ci
npm run security:check
npm run release:pack
```

产物位于 `release/codex-web-manager-<version>-win-x64.zip`，不包含 `data/`、`.env`、日志、源码依赖或账号信息。

创建补丁版本并触发 GitHub Release：

```powershell
npm version patch
git push origin main --follow-tags
```

也可以使用 `npm version minor` 或 `npm version major`。推送 `v*` 标签后，`.github/workflows/release.yml` 会在 Windows Runner 上执行安全扫描、构建 ZIP 并创建 GitHub Release。

## 其他环境部署

从 GitHub Release 下载 ZIP 后：

```powershell
Expand-Archive .\codex-web-manager-0.1.5-win-x64.zip -DestinationPath C:\Tools
Set-Location C:\Tools\codex-web-manager-0.1.5
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/setup.ps1
```

发布 ZIP 已包含构建后的前端，运行时不需要 `npm install`。目标机器仍需 Node.js 22.5+ 和 Codex Desktop。需要局域网访问时给 `setup.ps1` 增加 `-Lan`。

新机器建议重新导入账号。若确实要迁移 `data/`，只能通过可信的加密通道单独复制，并检查 `data/config.json` 中的本机绝对路径；不要通过 Git 或 Release 迁移。OAuth token 和 API Key 当前以 Codex 兼容的本地文件格式保存，并非应用级加密。

升级时停止旧服务、备份本地 `data/`、解压新版覆盖程序文件，再启动服务。不要用新版 ZIP 覆盖或删除现有 `data/` 和 `.env`。
