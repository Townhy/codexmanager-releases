import { spawn } from "node:child_process";

export class CodexAppServerClient {
  constructor({ executable, profile, version, onNotification }) {
    this.executable = executable;
    this.profile = profile;
    this.version = version;
    this.onNotification = onNotification;
    this.nextId = 1;
    this.pending = new Map();
    this.resumedThreads = new Set();
    this.starting = null;
    this.process = null;
    this.buffer = "";
  }

  async ensureStarted() {
    if (this.process && !this.process.killed) return;
    if (this.starting) return this.starting;
    this.starting = this.start().finally(() => { this.starting = null; });
    return this.starting;
  }

  async start() {
    const child = spawn(this.executable, ["app-server", "--stdio"], {
      cwd: this.profile.home,
      windowsHide: true,
      env: { ...process.env, CODEX_HOME: this.profile.home },
      stdio: ["pipe", "pipe", "pipe"],
    });
    this.process = child;
    this.buffer = "";
    child.stdout.setEncoding("utf8");
    child.stdout.on("data", (chunk) => this.consume(chunk));
    let stderr = "";
    child.stderr.setEncoding("utf8");
    child.stderr.on("data", (chunk) => { stderr = (stderr + chunk).slice(-8000); });
    child.on("close", (code) => {
      const error = new Error(stderr.trim() || `Codex app-server exited with code ${code}`);
      for (const pending of this.pending.values()) pending.reject(error);
      this.pending.clear();
      this.resumedThreads.clear();
      this.process = null;
      this.onNotification?.({ method: "app-server/disconnected", params: { error: error.message } });
    });
    child.on("error", (error) => {
      for (const pending of this.pending.values()) pending.reject(error);
      this.pending.clear();
    });
    await this.request("initialize", {
      clientInfo: { name: "codex-web-manager", title: "Codex Web Manager", version: this.version },
      capabilities: { experimentalApi: true },
    });
    this.notify("initialized", {});
  }

  consume(chunk) {
    this.buffer += chunk;
    const lines = this.buffer.split(/\r?\n/);
    this.buffer = lines.pop() || "";
    for (const line of lines) {
      if (!line.trim()) continue;
      try { this.handleMessage(JSON.parse(line)); } catch { /* Ignore non-protocol output. */ }
    }
  }

  handleMessage(message) {
    if (message.id !== undefined && !message.method) {
      const pending = this.pending.get(message.id);
      if (!pending) return;
      this.pending.delete(message.id);
      clearTimeout(pending.timeout);
      if (message.error) pending.reject(new Error(message.error.message || JSON.stringify(message.error)));
      else pending.resolve(message.result);
      return;
    }
    if (message.method) this.onNotification?.(message);
  }

  request(method, params, timeoutMs = 30000) {
    if (!this.process?.stdin?.writable) return Promise.reject(new Error("Codex app-server is not connected"));
    const id = this.nextId++;
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`${method} timed out`));
      }, timeoutMs);
      this.pending.set(id, { resolve, reject, timeout });
      this.process.stdin.write(`${JSON.stringify({ id, method, params })}\n`);
    });
  }

  notify(method, params) {
    if (this.process?.stdin?.writable) this.process.stdin.write(`${JSON.stringify({ method, params })}\n`);
  }

  async resumeThread(threadId, options = {}) {
    await this.ensureStarted();
    if (this.resumedThreads.has(threadId)) return;
    await this.request("thread/resume", { threadId, excludeTurns: true, ...options }, 60000);
    this.resumedThreads.add(threadId);
  }

  async startTurn({ threadId, input, model, cwd, sandboxPolicy }) {
    await this.resumeThread(threadId, { model: model || null, cwd: cwd || null });
    return this.request("turn/start", {
      threadId,
      input: [{ type: "text", text: input, text_elements: [] }],
      model: model || null,
      cwd: cwd || null,
      approvalPolicy: "never",
      sandboxPolicy,
    }, 60000);
  }

  async steerTurn({ threadId, turnId, input }) {
    await this.ensureStarted();
    return this.request("turn/steer", {
      threadId,
      expectedTurnId: turnId,
      input: [{ type: "text", text: input, text_elements: [] }],
    });
  }

  async interruptTurn(threadId, turnId) {
    await this.ensureStarted();
    return this.request("turn/interrupt", { threadId, turnId });
  }

  close() {
    this.process?.kill();
    this.process = null;
  }
}
