import { createServer } from "node:http";
import { readFile, writeFile, mkdir, access, copyFile } from "node:fs/promises";
import { closeSync, existsSync, openSync, readdirSync, readFileSync, readSync, statSync } from "node:fs";
import { homedir, networkInterfaces } from "node:os";
import { join, resolve, extname, dirname } from "node:path";
import { randomBytes, randomUUID } from "node:crypto";
import { spawn, execFile } from "node:child_process";
import { promisify } from "node:util";
import { DatabaseSync } from "node:sqlite";
import { CodexAppServerClient } from "./app-server-client.js";

const execFileAsync = promisify(execFile);
const root = resolve(import.meta.dirname, "..");
const envPath = join(root, ".env");
if (existsSync(envPath) && typeof process.loadEnvFile === "function") process.loadEnvFile(envPath);
const resolveSettingPath = (value, fallback) => resolve(root, value || fallback);
const dataDir = resolveSettingPath(process.env.CODEX_WEB_MANAGER_DATA_DIR, "data");
const configPath = join(dataDir, "config.json");
const distDir = join(root, "dist");
const packageInfo = JSON.parse(readFileSync(join(root, "package.json"), "utf8"));
const appVersion = String(packageInfo.version || "0.0.0");
const currentUiVersion = () => {
  try {
    const stats = statSync(join(distDir, "index.html"));
    return `${stats.size}:${stats.mtimeMs}`;
  } catch {
    return appVersion;
  }
};
let lastUiVersion = currentUiVersion();
const port = Number(process.env.PORT || 6688);
const host = process.env.HOST || "127.0.0.1";
const running = new Map();
const jobs = new Map();
const appServers = new Map();
const statusClients = new Set();
const knownThreads = new Map();
const threadCache = new Map();
const conversationCache = new Map();
const conversationVersions = new Map();
const forcedInterrupts = new Map();
let sessionSnapshot = { fingerprint: "", sessions: [], at: 0 };

await mkdir(dataDir, { recursive: true });

async function loadConfig() {
  if (existsSync(configPath)) {
    const config = JSON.parse(await readFile(configPath, "utf8"));
    if (config.onboardingCompleted === undefined) config.onboardingCompleted = true;
    return config;
  }
  const config = {
    token: randomBytes(24).toString("base64url"),
    onboardingCompleted: false,
    profiles: [{ id: "default", name: "当前账号", home: join(homedir(), ".codex"), isDefault: true }],
  };
  await saveConfig(config);
  return config;
}

async function saveConfig(config) {
  await writeFile(configPath, JSON.stringify(config, null, 2), { encoding: "utf8", mode: 0o600 });
}

function json(response, status, payload) {
  response.writeHead(status, { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" });
  response.end(JSON.stringify(payload));
}

async function body(request) {
  const chunks = [];
  for await (const chunk of request) chunks.push(chunk);
  return chunks.length ? JSON.parse(Buffer.concat(chunks).toString("utf8")) : {};
}

function authorized(request, config) {
  const configuredToken = process.env.CODEX_WEB_MANAGER_TOKEN;
  if (!configuredToken) return true;
  const token = request.headers.authorization?.replace(/^Bearer\s+/i, "") || request.headers["x-codex-token"];
  return typeof token === "string" && token.length > 0 && token === configuredToken;
}

function findDatabases(home) {
  const candidates = [join(home, "state_5.sqlite")];
  const sqliteDir = join(home, "sqlite");
  if (existsSync(sqliteDir)) {
    for (const file of readdirSync(sqliteDir)) {
      const path = join(sqliteDir, file);
      if ([".db", ".sqlite", ".sqlite3"].includes(extname(file).toLowerCase())) candidates.push(path);
    }
  }
  return candidates.filter(existsSync);
}

function sessionIndexTitles(home) {
  const indexPath = join(home, "session_index.jsonl");
  const titles = new Map();
  if (!existsSync(indexPath)) return titles;
  for (const line of readFileSync(indexPath, "utf8").split(/\r?\n/)) {
    if (!line.trim()) continue;
    try {
      const item = JSON.parse(line);
      const id = item.id || item.thread_id;
      const title = item.thread_name || item.title;
      if (id && title) titles.set(id, String(title).trim());
    } catch {
      // Ignore a partial last line while Codex updates the index.
    }
  }
  return titles;
}

function desktopThreadDescriptions(home) {
  const statePath = join(home, ".codex-global-state.json");
  if (!existsSync(statePath)) return new Map();
  try {
    const state = JSON.parse(readFileSync(statePath, "utf8"));
    const descriptions = state["electron-persisted-atom-state"]?.["thread-descriptions-v1"] || {};
    return new Map(Object.entries(descriptions).map(([id, title]) => [id, String(title).trim()]));
  } catch { return new Map(); }
}

function availableModels(profiles, sessions) {
  const models = new Map();
  for (const profile of profiles) {
    const cachePath = join(profile.home, "models_cache.json");
    if (!existsSync(cachePath)) continue;
    try {
      const cache = JSON.parse(readFileSync(cachePath, "utf8"));
      for (const item of cache.models || []) {
        if (!item.slug || item.visibility === "hide") continue;
        models.set(item.slug, {
          id: String(item.slug),
          label: String(item.display_name || item.slug),
          priority: Number(item.priority ?? 999),
        });
      }
    } catch { /* A model cache can be replaced while Codex refreshes it. */ }
  }
  for (const session of sessions) {
    const id = String(session.model || "").trim();
    if (id && !models.has(id)) models.set(id, { id, label: id, priority: 1000 });
  }
  return [...models.values()].sort((left, right) => left.priority - right.priority || left.label.localeCompare(right.label));
}

function displayThreadTitle(row, indexedTitle) {
  if (indexedTitle) return indexedTitle;
  const source = String(row.first_user_message || row.title || "").trim();
  const delegation = source.match(/<input>([\s\S]*?)<\/input>/i)?.[1];
  const candidate = (delegation || source)
    .replace(/<[^>]+>/g, " ")
    .replace(/\[\d+\]\s+user:/gi, " ")
    .replace(/# Context from my IDE setup:[\s\S]*?## My request for Codex:/i, " ")
    .replace(/\s+/g, " ")
    .trim();
  if (!candidate) return "未命名会话";
  return candidate.length > 42 ? `${candidate.slice(0, 42)}...` : candidate;
}

const rolloutTrackers = new Map();
const staleRolloutMs = 5 * 60 * 1000;
function normalizeRolloutStatus(result, stats) {
  const age = Date.now() - stats.mtimeMs;
  if (result.status === "running" && age >= staleRolloutMs) {
    return { ...result, status: "interrupted", statusAt: new Date(stats.mtimeMs).toISOString(), activity: "执行已中断" };
  }
  if (["idle", "running"].includes(result.status) && age < 10000) {
    return { ...result, status: "running", statusAt: new Date(stats.mtimeMs).toISOString() };
  }
  return result;
}
function rolloutStatus(path) {
  if (!path || !existsSync(path)) return { status: "idle", statusAt: null, activity: null };
  try {
    const stats = statSync(path);
    const size = stats.size;
    const previous = rolloutTrackers.get(path);
    if (previous && previous.size === size) {
      return normalizeRolloutStatus(previous.result, stats);
    }
    const start = previous && size >= previous.size ? previous.size : Math.max(0, size - 8 * 1024 * 1024);
    const handle = openSync(path, "r");
    const buffer = Buffer.alloc(size - start);
    readSync(handle, buffer, 0, buffer.length, start);
    closeSync(handle);
    let status = previous?.result.status || "idle";
    let statusAt = previous?.result.statusAt || null;
    let activity = previous?.result.activity || null;
    for (const line of buffer.toString("utf8").split(/\r?\n/)) {
      try {
        const event = JSON.parse(line);
        const type = event.payload?.type;
        if (event.type === "event_msg") {
          if (type === "task_started") { status = "running"; activity = "正在思考"; }
          if (type === "agent_reasoning") activity = "正在思考";
          if (type === "agent_message") activity = "正在回复";
          if (type === "task_complete") { status = "completed"; activity = null; }
          if (type === "task_failed") { status = "failed"; activity = null; }
          if (["task_started", "task_complete", "task_failed"].includes(type)) statusAt = event.timestamp || statusAt;
        }
        if (event.type === "response_item") {
          if (type === "reasoning") activity = "正在思考";
          if (["custom_tool_call", "function_call", "command_execution"].includes(type)) activity = "正在运行工具";
          if (["custom_tool_call_output", "function_call_output"].includes(type)) activity = "正在处理结果";
          if (type === "message" && event.payload?.role === "assistant") activity = "正在回复";
        }
      } catch { /* Tail can start in the middle of a JSON line. */ }
    }
    const result = { status, statusAt, activity };
    rolloutTrackers.set(path, { size, result });
    return normalizeRolloutStatus(result, stats);
  } catch { return { status: "idle", statusAt: null, activity: null }; }
}

function sessionRuntimeStatus(threadId, path) {
  const status = rolloutStatus(path);
  const interruptedAt = forcedInterrupts.get(threadId);
  if (!interruptedAt) return status;
  if (path && existsSync(path)) {
    try {
      if (statSync(path).mtimeMs > interruptedAt + 500) {
        forcedInterrupts.delete(threadId);
        return status;
      }
    } catch { /* Keep the forced state while the rollout is unavailable. */ }
  }
  return { status: "interrupted", statusAt: new Date(interruptedAt).toISOString(), activity: "已从 Web Manager 强制停止" };
}

function readThreads(profile) {
  const threads = new Map();
  const indexedTitles = sessionIndexTitles(profile.home);
  const desktopTitles = desktopThreadDescriptions(profile.home);
  for (const dbPath of findDatabases(profile.home)) {
    let db;
    try {
      db = new DatabaseSync(dbPath, { readOnly: true });
      const hasThreads = db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='threads'").get();
      if (!hasThreads) continue;
      const columns = new Set(db.prepare("PRAGMA table_info(threads)").all().map((column) => column.name));
      const pick = (name, fallback) => columns.has(name) ? name : `${fallback} AS ${name}`;
      const pickExcerpt = (name) => columns.has(name) ? `substr(${name}, 1, 1000) AS ${name}` : `'' AS ${name}`;
      const rows = db.prepare(`SELECT id, ${pick("title", "''")}, ${pickExcerpt("first_user_message")}, ${pick("rollout_path", "''")}, ${pick("cwd", "''")}, ${pick("model", "NULL")}, ${pick("model_provider", "''")}, ${pick("tokens_used", "0")}, ${pick("archived", "0")}, ${pick("updated_at_ms", "updated_at * 1000")}, ${pickExcerpt("preview")} FROM threads ORDER BY updated_at_ms DESC LIMIT 2000`).all();
      for (const row of rows) {
        const runtimeStatus = sessionRuntimeStatus(row.id, row.rollout_path);
        const activeJob = [...jobs.values()].find((job) => job.threadId === row.id && job.status === "running");
        const thread = { ...row, title: displayThreadTitle(row, desktopTitles.get(row.id) || indexedTitles.get(row.id)), status: activeJob ? "running" : runtimeStatus.status, statusAt: activeJob ? new Date(activeJob.startedAt).toISOString() : runtimeStatus.statusAt, activity: activeJob ? "正在处理" : runtimeStatus.activity, activeJobId: activeJob?.id || null, profileId: profile.id, profileName: profile.name, dbPath };
        threads.set(row.id, thread);
        threadCache.set(row.id, thread);
        knownThreads.set(row.id, { path: row.rollout_path, updatedAt: row.updated_at_ms });
      }
    } catch {
      // A live Codex database can briefly be unavailable while its schema is migrating.
    } finally {
      db?.close();
    }
  }
  return [...threads.values()];
}

function aggregateSessions(profiles, query = "") {
  const normalized = query.trim().toLowerCase();
  const sessions = new Map();
  for (const profile of profiles) {
    for (const thread of readThreads(profile)) {
      const existing = sessions.get(thread.id);
      const location = { profileId: profile.id, profileName: profile.name };
      if (!existing) sessions.set(thread.id, { ...thread, locations: [location] });
      else {
        existing.locations.push(location);
        if ((thread.updated_at_ms || 0) > (existing.updated_at_ms || 0)) Object.assign(existing, thread, { locations: existing.locations });
      }
    }
  }
  return [...sessions.values()]
    .filter((item) => !normalized || [item.title, item.cwd, item.preview, item.model].some((value) => String(value || "").toLowerCase().includes(normalized)))
    .sort((a, b) => Number(b.updated_at_ms || 0) - Number(a.updated_at_ms || 0));
}

function sessionSourceFingerprint(profiles) {
  const sources = [];
  for (const profile of profiles) {
    for (const path of [
      ...findDatabases(profile.home).flatMap((dbPath) => [dbPath, `${dbPath}-wal`]),
      join(profile.home, "session_index.jsonl"),
      join(profile.home, ".codex-global-state.json"),
    ]) {
      if (!existsSync(path)) continue;
      try {
        const stats = statSync(path);
        sources.push(`${path}:${stats.size}:${stats.mtimeMs}`);
      } catch { /* A live database can rotate its WAL between checks. */ }
    }
  }
  return sources.join("|");
}

function allSessions(profiles, force = false) {
  const fingerprint = sessionSourceFingerprint(profiles);
  if (!force && sessionSnapshot.sessions.length && fingerprint === sessionSnapshot.fingerprint) return sessionSnapshot.sessions;
  const sessions = aggregateSessions(profiles);
  sessionSnapshot = { fingerprint, sessions, at: Date.now() };
  return sessions;
}

function filterSessions(sessions, query = "") {
  const normalized = query.trim().toLowerCase();
  if (!normalized) return sessions;
  return sessions.filter((item) => [item.title, item.cwd, item.preview, item.model].some((value) => String(value || "").toLowerCase().includes(normalized)));
}

function accessUrls() {
  const urls = [`http://127.0.0.1:${port}`];
  for (const addresses of Object.values(networkInterfaces())) {
    for (const address of addresses || []) {
      if (address.family === "IPv4" && !address.internal) urls.push(`http://${address.address}:${port}`);
    }
  }
  return [...new Set(urls)];
}

function findThread(profiles, threadId) {
  const cached = threadCache.get(threadId);
  if (cached) return cached;
  for (const profile of profiles) {
    for (const dbPath of findDatabases(profile.home)) {
      let db;
      try {
        db = new DatabaseSync(dbPath, { readOnly: true });
        const row = db.prepare("SELECT id, title, cwd, rollout_path, model, model_provider, tokens_used, archived, updated_at_ms FROM threads WHERE id = ?").get(threadId);
        if (row) {
          const thread = { ...row, profileId: profile.id, profileName: profile.name, dbPath };
          threadCache.set(threadId, thread);
          return thread;
        }
      } catch {
        // Try the next profile database.
      } finally { db?.close(); }
    }
  }
  return null;
}

function textFromContent(content) {
  if (!Array.isArray(content)) return "";
  return content.map((item) => item?.text || item?.input_text || item?.output_text || "").filter(Boolean).join("\n").trim();
}

function readConversation(thread) {
  if (!thread.rollout_path || !existsSync(thread.rollout_path)) return [];
  const path = thread.rollout_path;
  const size = statSync(path).size;
  let cached = conversationCache.get(path);
  if (!cached || size < cached.size) cached = { size: 0, remainder: Buffer.alloc(0), messages: [] };
  if (size === cached.size) return cached.messages;
  const handle = openSync(path, "r");
  const appended = Buffer.alloc(size - cached.size);
  readSync(handle, appended, 0, appended.length, cached.size);
  closeSync(handle);
  const input = Buffer.concat([cached.remainder, appended]);
  const lastNewline = input.lastIndexOf(10);
  if (lastNewline < 0) {
    cached.remainder = input;
    cached.size = size;
    conversationCache.set(path, cached);
    return cached.messages;
  }
  const lines = input.subarray(0, lastNewline).toString("utf8").split(/\r?\n/);
  const messages = cached.messages;
  for (const line of lines) {
    if (!line.trim()) continue;
    try {
      const event = JSON.parse(line);
      if (event.type !== "event_msg") continue;
      const eventType = event.payload?.type;
      if (eventType !== "user_message" && eventType !== "agent_message") continue;
      const role = eventType === "user_message" ? "user" : "assistant";
      const content = String(event.payload.message || "").trim();
      if (!content || content.startsWith("<environment_context>")) continue;
      const previous = messages.at(-1);
      if (previous?.role === role && previous.content === content) continue;
      messages.push({ id: `${event.timestamp}-${messages.length}`, role, content, timestamp: event.timestamp, phase: event.payload.phase || null });
    } catch {
      // Ignore partial lines while Codex is appending to an active rollout.
    }
  }
  cached = { size, remainder: input.subarray(lastNewline + 1), messages };
  conversationCache.set(path, cached);
  return messages;
}

function cockpitRoot() { return resolveSettingPath(process.env.CODEX_COCKPIT_ROOT, join(homedir(), ".antigravity_cockpit")); }
function loadCockpitAccounts() {
  const indexPath = join(cockpitRoot(), "codex_accounts.json");
  if (!existsSync(indexPath)) return [];
  try {
    const index = JSON.parse(readFileSync(indexPath, "utf8"));
    return (index.accounts || []).map((account) => ({
      id: account.id,
      email: account.email || account.id,
      planType: account.plan_type || "unknown",
      current: index.current_account_id === account.id,
      imported: false,
      lastUsed: account.last_used || null,
    }));
  } catch { return []; }
}

function currentCockpitAccount() {
  const accounts = loadCockpitAccounts();
  return accounts.find((account) => account.current) || null;
}

let processCache = { at: 0, rows: [] };
async function codexProcessRows() {
  if (Date.now() - processCache.at < 3000) return processCache.rows;
  try {
    const script = "Get-CimInstance Win32_Process -Filter \"Name='ChatGPT.exe'\" | Select-Object ProcessId,ParentProcessId,CommandLine | ConvertTo-Json -Compress";
    const { stdout } = await execFileAsync("powershell.exe", ["-NoProfile", "-Command", script], { windowsHide: true });
    const parsed = stdout.trim() ? JSON.parse(stdout) : [];
    processCache = { at: Date.now(), rows: Array.isArray(parsed) ? parsed : [parsed] };
  } catch { processCache = { at: Date.now(), rows: [] }; }
  return processCache.rows;
}

async function profilesWithRuntime(config, includeThreadCounts = true, threadCounts = null) {
  const processes = await codexProcessRows();
  const defaultMain = processes.find((process) => process.CommandLine && !process.CommandLine.includes("--type="));
  const currentAccount = currentCockpitAccount();
  const resolved = config.profiles.map((profile) => {
    let runtime = running.get(profile.id) || null;
    if (!runtime && profile.isDefault && defaultMain) runtime = { pid: defaultMain.ProcessId, startedAt: null, external: true };
    if (!runtime && !profile.isDefault) {
      const marker = join(profile.home, "electron").toLowerCase().replaceAll("/", "\\");
      const matched = processes.find((process) => String(process.CommandLine || "").toLowerCase().includes(marker));
      if (matched) runtime = { pid: matched.ParentProcessId || matched.ProcessId, startedAt: null, external: true };
    }
    const cockpitAccount = profile.cockpitAccountId ? loadCockpitAccounts().find((account) => account.id === profile.cockpitAccountId) : profile.isDefault ? currentAccount : null;
    return { ...profile, running: runtime, threadCount: includeThreadCounts ? threadCounts?.get(profile.id) ?? readThreads(profile).length : undefined, account: cockpitAccount ? { id: cockpitAccount.id, label: cockpitAccount.email, type: cockpitAccount.planType } : null };
  });
  const activeAccounts = new Map(resolved.filter((profile) => profile.running && profile.account).map((profile) => [profile.account.id, { profileId: profile.id, pid: profile.running.pid }]));
  return resolved.map((profile) => ({ ...profile, accountRuntime: profile.account ? activeAccounts.get(profile.account.id) || null : null }));
}

function tomlString(value) { return JSON.stringify(String(value || "")); }
async function importCockpitAccount(config, accountId) {
  const accountPath = join(cockpitRoot(), "codex_accounts", `${accountId}.json`);
  if (!existsSync(accountPath)) throw new Error("Cockpit 账号详情不存在");
  const account = JSON.parse(await readFile(accountPath, "utf8"));
  const existing = config.profiles.find((profile) => profile.cockpitAccountId === accountId);
  if (existing) return existing;
  const home = join(dataDir, "profiles", accountId);
  await mkdir(home, { recursive: true });
  const isApiKey = String(account.auth_mode || "").toLowerCase().includes("api") || accountId.startsWith("codex_apikey_");
  if (isApiKey) {
    const apiKey = account.openai_api_key;
    if (!apiKey) throw new Error("Cockpit API 账号缺少密钥");
    await writeFile(join(home, "auth.json"), JSON.stringify({ auth_mode: "apikey", OPENAI_API_KEY: apiKey }, null, 2), { mode: 0o600 });
    const baseUrl = account.api_base_url || "https://api.openai.com/v1";
    const providerName = account.api_provider_name || account.email || "Cockpit API";
    const configToml = `model_provider = "cockpit_import"\n\n[model_providers.cockpit_import]\nname = ${tomlString(providerName)}\nbase_url = ${tomlString(baseUrl)}\nwire_api = "responses"\nrequires_openai_auth = true\nexperimental_bearer_token = ${tomlString(apiKey)}\nsupports_websockets = ${Boolean(account.api_supports_websockets)}\n`;
    await writeFile(join(home, "config.toml"), configToml, { encoding: "utf8", mode: 0o600 });
  } else {
    const tokens = account.tokens || {};
    if (!tokens.access_token) throw new Error("Cockpit OAuth 账号缺少 access token");
    await writeFile(join(home, "auth.json"), JSON.stringify({ OPENAI_API_KEY: null, tokens: { id_token: tokens.id_token || "", access_token: tokens.access_token, refresh_token: tokens.refresh_token || "", account_id: account.account_id || null }, last_refresh: new Date().toISOString() }, null, 2), { mode: 0o600 });
    await writeFile(join(home, "config.toml"), "", { encoding: "utf8", mode: 0o600 });
  }
  const profile = { id: randomUUID(), name: account.email || accountId, home, args: [], cockpitAccountId: accountId, accountType: isApiKey ? "API" : account.plan_type || "OAuth" };
  config.profiles.push(profile);
  await saveConfig(config);
  return profile;
}

async function setArchived(profiles, threadId, archived) {
  let changed = 0;
  for (const profile of profiles) {
    for (const dbPath of findDatabases(profile.home)) {
      let db;
      try {
        db = new DatabaseSync(dbPath);
        const hasThreads = db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='threads'").get();
        if (!hasThreads) continue;
        const columns = new Set(db.prepare("PRAGMA table_info(threads)").all().map((column) => column.name));
        if (!columns.has("archived")) continue;
        const result = columns.has("archived_at")
          ? db.prepare("UPDATE threads SET archived = ?, archived_at = ? WHERE id = ?").run(archived ? 1 : 0, archived ? Math.floor(Date.now() / 1000) : null, threadId)
          : db.prepare("UPDATE threads SET archived = ? WHERE id = ?").run(archived ? 1 : 0, threadId);
        changed += Number(result.changes || 0);
      } finally { db?.close(); }
    }
  }
  return changed;
}

async function resolveLaunchPath(profile) {
  if (profile.launchPath && existsSync(profile.launchPath)) return profile.launchPath;
  if (process.env.CODEX_DESKTOP_LAUNCH_PATH && existsSync(process.env.CODEX_DESKTOP_LAUNCH_PATH)) return resolve(process.env.CODEX_DESKTOP_LAUNCH_PATH);
  const script = "Get-AppxPackage OpenAI.Codex | Sort-Object Version -Descending | Select-Object -First 1 -ExpandProperty InstallLocation";
  const { stdout } = await execFileAsync("powershell.exe", ["-NoProfile", "-Command", script], { windowsHide: true });
  const install = stdout.trim();
  for (const relative of ["app\\ChatGPT.exe", "app\\Codex.exe", "ChatGPT.exe", "Codex.exe"]) {
    const candidate = join(install, relative);
    if (existsSync(candidate)) return candidate;
  }
  throw new Error("没有找到 ChatGPT.exe，请在 Profile 中设置启动路径");
}

function resolveCodexCli() {
  if (process.env.CODEX_DESKTOP_CLI && existsSync(process.env.CODEX_DESKTOP_CLI)) return resolve(process.env.CODEX_DESKTOP_CLI);
  const base = join(process.env.LOCALAPPDATA || "", "OpenAI", "Codex", "bin");
  const nested = existsSync(base)
    ? readdirSync(base, { withFileTypes: true })
        .filter((entry) => entry.isDirectory())
        .map((entry) => join(base, entry.name, "codex.exe"))
        .filter(existsSync)
        .sort((left, right) => statSync(right).mtimeMs - statSync(left).mtimeMs)
    : [];
  const candidates = [...nested, join(base, "codex.exe")];
  const found = candidates.find(existsSync);
  if (!found) throw new Error("没有找到可执行的 Codex CLI");
  return found;
}

function publishJob(job, event) {
  const item = { ...event, at: Date.now() };
  job.events.push(item);
  if (job.events.length > 500) job.events.shift();
  for (const response of job.clients) response.write(`data: ${JSON.stringify(item)}\n\n`);
}

async function cancelJob(job) {
  if (job.status !== "running") return job.status;
  job.status = "cancelled";
  job.finishedAt = Date.now();
  publishJob(job, { type: "cancelled", message: "任务已取消" });
  if (job.client && job.turnId) await job.client.interruptTurn(job.threadId, job.turnId).catch(() => {});
  else if (job.pid) await execFileAsync("taskkill.exe", ["/PID", String(job.pid), "/T", "/F"], { windowsHide: true }).catch(() => {});
  return job.status;
}

async function cancelRecoveredResumeProcess(threadId) {
  const script = "Get-CimInstance Win32_Process -Filter \"Name='codex.exe'\" | Select-Object ProcessId,CommandLine | ConvertTo-Json -Compress";
  let rows = [];
  try {
    const { stdout } = await execFileAsync("powershell.exe", ["-NoProfile", "-Command", script], { windowsHide: true });
    const parsed = stdout.trim() ? JSON.parse(stdout) : [];
    rows = Array.isArray(parsed) ? parsed : [parsed];
  } catch {
    return null;
  }
  const matching = rows.find((process) => {
    const commandLine = String(process.CommandLine || "");
    return /\bexec\s+resume\b/i.test(commandLine) && commandLine.split(/\s+/).includes(threadId);
  });
  if (!matching?.ProcessId) return null;
  await execFileAsync("taskkill.exe", ["/PID", String(matching.ProcessId), "/T", "/F"], { windowsHide: true }).catch(() => {});
  return { status: "cancelled", recovered: true, pid: matching.ProcessId };
}

async function cancelDesktopAppServer(config, profileId, threadId) {
  const profiles = await profilesWithRuntime(config, false);
  const runtime = profiles.find((profile) => profile.id === profileId)?.running;
  if (!runtime?.pid) return null;
  const script = "Get-CimInstance Win32_Process -Filter \"Name='codex.exe'\" | Select-Object ProcessId,ParentProcessId,ExecutablePath,CommandLine | ConvertTo-Json -Compress";
  let rows = [];
  try {
    const { stdout } = await execFileAsync("powershell.exe", ["-NoProfile", "-Command", script], { windowsHide: true });
    const parsed = stdout.trim() ? JSON.parse(stdout) : [];
    rows = Array.isArray(parsed) ? parsed : [parsed];
  } catch {
    return null;
  }
  const appServer = rows.find((process) => {
    const executable = String(process.ExecutablePath || "").toLowerCase();
    const commandLine = String(process.CommandLine || "");
    return Number(process.ParentProcessId) === Number(runtime.pid)
      && executable.includes("\\windowsapps\\")
      && /\bapp-server\b/i.test(commandLine);
  });
  if (!appServer?.ProcessId) return null;
  forcedInterrupts.set(threadId, Date.now());
  await execFileAsync("taskkill.exe", ["/PID", String(appServer.ProcessId), "/T", "/F"], { windowsHide: true });
  processCache.at = 0;
  return { status: "cancelled", desktop: true, pid: appServer.ProcessId };
}

function sessionSummary(session) {
  const { first_user_message, preview, rollout_path, dbPath, ...summary } = session;
  return summary;
}

function completeJob(job, status, message, code = undefined) {
  if (job.status === "cancelled") {
    for (const response of job.clients) response.end();
    job.clients.clear();
    return;
  }
  job.status = status;
  job.finishedAt = Date.now();
  publishJob(job, { type: status, code, message });
  for (const response of job.clients) response.end();
  job.clients.clear();
}

function handleAppServerNotification(profileId, event) {
  const threadId = event.params?.threadId;
  const job = [...jobs.values()].find((item) => item.profileId === profileId && item.threadId === threadId && item.status === "running");
  if (event.method === "app-server/disconnected") {
    for (const active of jobs.values()) {
      if (active.profileId === profileId && active.status === "running") completeJob(active, "failed", event.params?.error || "Codex app-server 连接已断开");
    }
    return;
  }
  if (!job) return;
  if (event.method === "turn/started") {
    job.turnId = event.params.turn.id;
    publishJob(job, { type: "progress", rawType: event.method, turnId: job.turnId });
  } else if (event.method === "item/agentMessage/delta") {
    job.liveMessage = `${job.liveMessage || ""}${event.params.delta || ""}`;
    publishJob(job, { type: "message", message: job.liveMessage, rawType: event.method });
  } else if (event.method === "turn/completed") {
    const turn = event.params.turn;
    if (turn.status === "completed") completeJob(job, "completed", "任务已完成", 0);
    else if (turn.status === "interrupted") completeJob(job, "cancelled", "任务已取消");
    else completeJob(job, "failed", turn.error?.message || `Codex turn 状态：${turn.status}`);
  } else if (event.method === "error" && !event.params.willRetry) {
    completeJob(job, "failed", event.params.error?.message || "Codex 执行失败");
  }
}

function appServerFor(profile) {
  let client = appServers.get(profile.id);
  if (client) return client;
  client = new CodexAppServerClient({
    executable: resolveCodexCli(),
    profile,
    version: appVersion,
    onNotification: (event) => handleAppServerNotification(profile.id, event),
  });
  appServers.set(profile.id, client);
  return client;
}

function sandboxPolicy(permission, thread) {
  if (permission === "danger-full-access") return { type: "dangerFullAccess" };
  if (permission === "workspace-write") return { type: "workspaceWrite", writableRoots: [thread.cwd], networkAccess: false };
  return undefined;
}

function startResumeJob(profile, thread, prompt, model, permission) {
  const id = randomUUID();
  const job = { id, threadId: thread.id, profileId: profile.id, status: "running", events: [], clients: new Set(), startedAt: Date.now() };
  jobs.set(id, job);
  const client = appServerFor(profile);
  job.client = client;
  const cwd = existsSync(thread.cwd) ? thread.cwd : profile.home;
  client.startTurn({ threadId: thread.id, input: prompt, model, cwd, sandboxPolicy: sandboxPolicy(permission, thread) })
    .then((result) => {
      job.turnId ||= result?.turn?.id;
      if (job.status === "cancelled" && job.turnId) client.interruptTurn(job.threadId, job.turnId).catch(() => {});
    })
    .catch((error) => completeJob(job, "failed", error.message));
  return job;
}

async function launchProfile(profile) {
  await mkdir(profile.home, { recursive: true });
  const executable = await resolveLaunchPath(profile);
  const electronHome = join(profile.home, "electron");
  await mkdir(electronHome, { recursive: true });
  const child = spawn(executable, profile.args || [], {
    detached: true,
    windowsHide: false,
    stdio: "ignore",
    env: { ...process.env, CODEX_HOME: profile.home, CODEX_ELECTRON_USER_DATA_PATH: electronHome },
  });
  child.unref();
  running.set(profile.id, { pid: child.pid, startedAt: Date.now() });
  return child.pid;
}

async function stopProfile(profileId) {
  const process = running.get(profileId);
  if (!process) throw new Error("该实例不是由本控制台启动，无法安全停止");
  await execFileAsync("taskkill.exe", ["/PID", String(process.pid), "/T", "/F"], { windowsHide: true }).catch(() => {});
  running.delete(profileId);
}

async function route(request, response) {
  const config = await loadConfig();
  const url = new URL(request.url, `http://${request.headers.host}`);
  if (url.pathname === "/api/health") return json(response, 200, { ok: true, version: appVersion, authRequired: Boolean(process.env.CODEX_WEB_MANAGER_TOKEN) });
  if (!url.pathname.startsWith("/api/")) return serveStatic(url.pathname, response);
  if (!authorized(request, config)) return json(response, 401, { error: "访问令牌无效" });

  try {
    if (request.method === "GET" && url.pathname === "/api/bootstrap") {
      const completeSessions = allSessions(config.profiles);
      const sessions = filterSessions(completeSessions, url.searchParams.get("q") || "");
      const threadCounts = new Map(config.profiles.map((profile) => [profile.id, 0]));
      for (const session of completeSessions) {
        for (const location of session.locations) threadCounts.set(location.profileId, (threadCounts.get(location.profileId) || 0) + 1);
      }
      const runtimeProfiles = await profilesWithRuntime(config, true, threadCounts);
      return json(response, 200, {
        profiles: runtimeProfiles,
        sessions: sessions.slice(0, 500).map(sessionSummary),
        stats: { profiles: config.profiles.length, sessions: completeSessions.length, running: runtimeProfiles.filter((profile) => profile.running).length, tokens: completeSessions.reduce((sum, item) => sum + Number(item.tokens_used || 0), 0) },
        system: { accessUrls: accessUrls(), trustedMode: !process.env.CODEX_WEB_MANAGER_TOKEN, version: appVersion, uiVersion: currentUiVersion(), onboardingRequired: config.onboardingCompleted === false },
        models: availableModels(config.profiles, completeSessions),
        cockpitAccounts: loadCockpitAccounts().map((account) => ({ ...account, imported: config.profiles.some((profile) => profile.cockpitAccountId === account.id) })),
      });
    }
    if (request.method === "POST" && url.pathname === "/api/cockpit/import") {
      const input = await body(request);
      if (!input.accountId) throw new Error("请选择 Cockpit 账号");
      return json(response, 201, await importCockpitAccount(config, String(input.accountId)));
    }
    if (request.method === "POST" && url.pathname === "/api/onboarding/complete") {
      config.onboardingCompleted = true;
      await saveConfig(config);
      return json(response, 200, { completed: true });
    }
    if (request.method === "POST" && url.pathname === "/api/profiles") {
      const input = await body(request);
      if (!input.name?.trim() || !input.home?.trim()) throw new Error("名称和 CODEX_HOME 不能为空");
      const home = resolve(input.home.trim());
      if (config.profiles.some((profile) => profile.home.toLowerCase() === home.toLowerCase())) throw new Error("该 CODEX_HOME 已存在");
      const profile = { id: randomUUID(), name: input.name.trim(), home, launchPath: input.launchPath?.trim() || undefined, args: [] };
      await mkdir(home, { recursive: true });
      if (input.copyFromProfileId) {
        const source = config.profiles.find((item) => item.id === input.copyFromProfileId);
        if (!source) throw new Error("复制来源 Profile 不存在");
        for (const file of ["auth.json", "config.toml", "models_cache.json"]) {
          const sourcePath = join(source.home, file);
          if (existsSync(sourcePath)) await copyFile(sourcePath, join(home, file));
        }
      }
      config.profiles.push(profile);
      await saveConfig(config);
      return json(response, 201, profile);
    }
    const profileRoute = url.pathname.match(/^\/api\/profiles\/([^/]+)$/);
    if (profileRoute && request.method === "PUT") {
      const profile = config.profiles.find((item) => item.id === profileRoute[1]);
      if (!profile) return json(response, 404, { error: "Profile 不存在" });
      const input = await body(request);
      if (input.name !== undefined) profile.name = String(input.name).trim() || profile.name;
      if (input.home !== undefined && !profile.isDefault) profile.home = resolve(String(input.home).trim());
      if (input.launchPath !== undefined) profile.launchPath = String(input.launchPath).trim() || undefined;
      if (Array.isArray(input.args)) profile.args = input.args.map(String);
      await saveConfig(config);
      return json(response, 200, profile);
    }
    if (profileRoute && request.method === "DELETE") {
      const index = config.profiles.findIndex((item) => item.id === profileRoute[1]);
      if (index < 0) return json(response, 404, { error: "Profile 不存在" });
      if (config.profiles[index].isDefault) throw new Error("默认 Profile 不能移除");
      if (running.has(profileRoute[1])) throw new Error("请先停止该实例");
      const [removed] = config.profiles.splice(index, 1);
      await saveConfig(config);
      return json(response, 200, { removed, filesPreserved: true });
    }
    const sessionRoute = url.pathname.match(/^\/api\/sessions\/([^/]+)(?:\/(archive|open|cancel|steer))?$/);
    if (sessionRoute) {
      const threadId = decodeURIComponent(sessionRoute[1]);
      const thread = findThread(config.profiles, threadId);
      if (!thread) return json(response, 404, { error: "会话不存在" });
      if (request.method === "GET" && !sessionRoute[2]) {
        const activeJob = [...jobs.values()].find((job) => job.threadId === threadId && job.status === "running");
        const runtimeStatus = rolloutStatus(thread.rollout_path);
        const liveThread = {
          ...thread,
          status: activeJob ? "running" : runtimeStatus.status,
          statusAt: activeJob ? new Date(activeJob.startedAt).toISOString() : runtimeStatus.statusAt,
          activity: activeJob ? "正在处理" : runtimeStatus.activity,
          activeJobId: activeJob?.id || null,
        };
        const allMessages = readConversation(thread);
        const limit = Math.min(1000, Math.max(50, Number(url.searchParams.get("limit")) || 300));
        const requestedEnd = url.searchParams.has("before") ? Number(url.searchParams.get("before")) : allMessages.length;
        const end = Math.min(allMessages.length, Math.max(0, Number.isFinite(requestedEnd) ? requestedEnd : allMessages.length));
        const start = Math.max(0, end - limit);
        return json(response, 200, {
          thread: liveThread,
          messages: allMessages.slice(start, end),
          messagePage: { start, end, total: allMessages.length, hasMore: start > 0 },
        });
      }
      if (request.method === "POST" && sessionRoute[2] === "archive") {
        const input = await body(request);
        const changed = await setArchived(config.profiles, threadId, input.archived !== false);
        return json(response, 200, { changed });
      }
      if (request.method === "POST" && sessionRoute[2] === "open") {
        const target = thread.rollout_path && existsSync(thread.rollout_path) ? dirname(thread.rollout_path) : thread.cwd;
        spawn("explorer.exe", [target], { detached: true, stdio: "ignore" }).unref();
        return json(response, 200, { ok: true });
      }
      if (request.method === "POST" && sessionRoute[2] === "cancel") {
        const activeJob = [...jobs.values()].find((job) => job.threadId === threadId && job.status === "running");
        if (!activeJob) {
          const recovered = await cancelRecoveredResumeProcess(threadId);
          if (recovered) return json(response, 200, recovered);
          const desktop = await cancelDesktopAppServer(config, thread.profileId, threadId);
          if (desktop) return json(response, 200, desktop);
          return json(response, 409, { error: "没有找到该 Profile 对应的活动 Codex 进程" });
        }
        return json(response, 200, { status: await cancelJob(activeJob), jobId: activeJob.id });
      }
      if (request.method === "POST" && sessionRoute[2] === "steer") {
        const activeJob = [...jobs.values()].find((job) => job.threadId === threadId && job.status === "running");
        if (!activeJob?.client || !activeJob.turnId) return json(response, 409, { error: "当前任务尚未进入可追加引导的阶段" });
        const input = await body(request);
        const prompt = String(input.message || "").trim();
        if (!prompt) throw new Error("追加内容不能为空");
        await activeJob.client.steerTurn({ threadId, turnId: activeJob.turnId, input: prompt });
        return json(response, 202, { status: "steered", jobId: activeJob.id, turnId: activeJob.turnId });
      }
    }
    const messageRoute = url.pathname.match(/^\/api\/sessions\/([^/]+)\/messages$/);
    if (request.method === "POST" && messageRoute) {
      const threadId = decodeURIComponent(messageRoute[1]);
      const thread = findThread(config.profiles, threadId);
      if (!thread) return json(response, 404, { error: "会话不存在" });
      const profile = config.profiles.find((item) => item.id === thread.profileId);
      const input = await body(request);
      const prompt = String(input.message || "").trim();
      const model = String(input.model || "").trim();
      const permission = String(input.permission || "inherit");
      if (!prompt) throw new Error("消息不能为空");
      if (model && !/^[A-Za-z0-9._:/-]{1,120}$/.test(model)) throw new Error("模型名称格式无效");
      if (!["inherit", "workspace-write", "danger-full-access"].includes(permission)) throw new Error("权限模式无效");
      const desktopStatus = rolloutStatus(thread.rollout_path);
      if (desktopStatus.status === "running") throw new Error("该会话正在 Codex Desktop 中执行，请等待完成后再发送");
      const active = [...jobs.values()].find((job) => job.threadId === threadId && job.status === "running");
      if (active) throw new Error("该任务正在执行，请等待当前回复完成");
      const job = startResumeJob(profile, thread, prompt, model || undefined, permission);
      return json(response, 202, { jobId: job.id, status: job.status });
    }
    const eventsRoute = url.pathname.match(/^\/api\/jobs\/([^/]+)\/events$/);
    if (request.method === "GET" && eventsRoute) {
      const job = jobs.get(eventsRoute[1]);
      if (!job) return json(response, 404, { error: "任务不存在" });
      response.writeHead(200, { "content-type": "text/event-stream", "cache-control": "no-cache, no-transform", connection: "keep-alive", "x-accel-buffering": "no" });
      response.socket?.setNoDelay(true);
      response.flushHeaders?.();
      for (const event of job.events) response.write(`data: ${JSON.stringify(event)}\n\n`);
      if (job.status !== "running") return response.end();
      job.clients.add(response);
      request.on("close", () => job.clients.delete(response));
      return;
    }
    if (request.method === "GET" && url.pathname === "/api/events") {
      response.writeHead(200, { "content-type": "text/event-stream", "cache-control": "no-cache, no-transform", connection: "keep-alive", "x-accel-buffering": "no" });
      response.socket?.setNoDelay(true);
      response.flushHeaders?.();
      response.write(`data: ${JSON.stringify({ type: "connected", at: Date.now(), uiVersion: currentUiVersion() })}\n\n`);
      statusClients.add(response);
      request.on("close", () => statusClients.delete(response));
      return;
    }
    const cancelRoute = url.pathname.match(/^\/api\/jobs\/([^/]+)\/cancel$/);
    if (request.method === "POST" && cancelRoute) {
      const job = jobs.get(cancelRoute[1]);
      if (!job) return json(response, 404, { error: "任务不存在" });
      return json(response, 200, { status: await cancelJob(job) });
    }
    const action = url.pathname.match(/^\/api\/profiles\/([^/]+)\/(launch|stop)$/);
    if (request.method === "POST" && action) {
      const profile = config.profiles.find((item) => item.id === action[1]);
      if (!profile) return json(response, 404, { error: "Profile 不存在" });
      if (action[2] === "launch") return json(response, 200, { pid: await launchProfile(profile) });
      await stopProfile(profile.id);
      return json(response, 200, { ok: true });
    }
    return json(response, 404, { error: "接口不存在" });
  } catch (error) {
    return json(response, 400, { error: error instanceof Error ? error.message : String(error) });
  }
}

async function serveStatic(pathname, response) {
  const requested = pathname === "/" ? "index.html" : pathname.slice(1);
  let path = resolve(distDir, requested);
  if (!path.startsWith(distDir)) return json(response, 403, { error: "禁止访问" });
  try { await access(path); } catch { path = join(distDir, "index.html"); }
  const types = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".svg": "image/svg+xml" };
  const extension = extname(path);
  const cacheControl = extension === ".html" || extension === ".webmanifest"
    ? "no-store, no-cache, must-revalidate"
    : requested.startsWith("assets/")
      ? "public, max-age=31536000, immutable"
      : "no-cache";
  try {
    const headers = {
      "content-type": types[extension] || "application/octet-stream",
      "cache-control": cacheControl,
    };
    if (extension === ".html") Object.assign(headers, { pragma: "no-cache", expires: "0" });
    response.writeHead(200, headers);
    response.end(await readFile(path));
  } catch {
    if (!response.headersSent) json(response, 503, { error: "前端正在更新，请稍后刷新" });
    else response.end();
  }
}

const server = createServer((request, response) => {
  route(request, response).catch((error) => {
    if (!response.headersSent) json(response, 500, { error: error instanceof Error ? error.message : String(error) });
    else response.end();
  });
});
let statusBroadcasting = false;
setInterval(async () => {
  if (!statusClients.size || statusBroadcasting) return;
  statusBroadcasting = true;
  try {
    const uiVersion = currentUiVersion();
    if (uiVersion !== lastUiVersion) {
      lastUiVersion = uiVersion;
      const reloadPayload = JSON.stringify({ type: "reload", at: Date.now(), uiVersion });
      for (const client of statusClients) client.write(`data: ${reloadPayload}\n\n`);
    }
    const config = await loadConfig();
    const sourceFingerprint = sessionSourceFingerprint(config.profiles);
    if (sourceFingerprint !== sessionSnapshot.fingerprint) {
      const sessions = allSessions(config.profiles, true);
      const sessionPayload = JSON.stringify({
        type: "sessions",
        at: Date.now(),
        sessions: sessions.slice(0, 500).map(sessionSummary),
        stats: {
          sessions: sessions.length,
          tokens: sessions.reduce((sum, item) => sum + Number(item.tokens_used || 0), 0),
        },
      });
      for (const client of statusClients) client.write(`data: ${sessionPayload}\n\n`);
    }
    const profiles = await profilesWithRuntime(config, false);
    const sessions = [...knownThreads.entries()].map(([id, thread]) => {
      const status = sessionRuntimeStatus(id, thread.path);
      const activeJob = [...jobs.values()].find((job) => job.threadId === id && job.status === "running");
      if (thread.path && existsSync(thread.path)) {
        try {
          const stats = statSync(thread.path);
          const version = `${stats.size}:${stats.mtimeMs}`;
          const previous = conversationVersions.get(id);
          conversationVersions.set(id, version);
          if (previous && previous !== version) {
            const changedPayload = JSON.stringify({ type: "conversation", id, at: Date.now() });
            for (const client of statusClients) client.write(`data: ${changedPayload}\n\n`);
          }
        } catch { /* The rollout may move while Codex repairs its index. */ }
      }
      return { id, status: activeJob ? "running" : status.status, statusAt: activeJob ? new Date(activeJob.startedAt).toISOString() : status.statusAt, activity: activeJob ? "正在处理" : status.activity, activeJobId: activeJob?.id || null, updatedAt: thread.updatedAt };
    });
    const payload = JSON.stringify({ type: "status", at: Date.now(), sessions, profiles: profiles.map((profile) => ({ id: profile.id, running: profile.running, accountRuntime: profile.accountRuntime })) });
    for (const client of statusClients) client.write(`data: ${payload}\n\n`);
  } catch { /* The next tick retries transient database locks. */ }
  finally { statusBroadcasting = false; }
}, 750).unref();
server.listen(port, host, async () => {
  const config = await loadConfig();
  console.log(`Codex Web Manager: http://${host}:${port}`);
  console.log(`Version: ${appVersion}`);
  console.log(`Data directory: ${dataDir}`);
  console.log(process.env.CODEX_WEB_MANAGER_TOKEN ? "Access token protection: enabled" : "Access mode: trusted local administrator");
});
