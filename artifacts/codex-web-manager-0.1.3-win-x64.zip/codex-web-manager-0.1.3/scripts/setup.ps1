param(
    [switch]$Lan,
    [switch]$NoStart
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$nodeCommand = Get-Command node -ErrorAction SilentlyContinue
if (!$nodeCommand) { throw "Node.js 22.5 or newer is required. Install it from https://nodejs.org/ first." }

$nodeVersionText = (& node --version).Trim().TrimStart("v")
$nodeVersion = [version]($nodeVersionText -replace '-.*$', '')
if ($nodeVersion -lt [version]"22.5.0") {
    throw "Node.js 22.5 or newer is required. Current version: $nodeVersionText"
}

if (!(Test-Path -LiteralPath (Join-Path $root "dist\index.html"))) {
    throw "Built frontend is missing. Download a GitHub Release ZIP or run npm ci and npm run build from source."
}

$envPath = Join-Path $root ".env"
if (!(Test-Path -LiteralPath $envPath)) {
    $listenHost = if ($Lan) { "0.0.0.0" } else { "127.0.0.1" }
    $content = @(
        "HOST=$listenHost",
        "PORT=6688",
        "CODEX_WEB_MANAGER_DATA_DIR=./data"
    ) -join [Environment]::NewLine
    Set-Content -LiteralPath $envPath -Value $content -Encoding UTF8
    Write-Output "Created local configuration: $envPath"
}

New-Item -ItemType Directory -Force -Path (Join-Path $root "data") | Out-Null

$codexHome = Join-Path $HOME ".codex"
if (Test-Path -LiteralPath $codexHome) {
    Write-Output "Detected Codex home: $codexHome"
} else {
    Write-Warning "No $codexHome directory was found. Install and sign in to Codex Desktop before importing sessions."
}

if ($NoStart) {
    Write-Output "Setup checks completed."
    exit 0
}

if ($Lan) { & (Join-Path $PSScriptRoot "start-web-manager.ps1") -Lan }
else { & (Join-Path $PSScriptRoot "start-web-manager.ps1") -Local }
if ($LASTEXITCODE -ne 0) { throw "Codex Web Manager failed to start." }

if ($Lan) {
    Write-Output "Open the LAN address shown on the Accounts page from another device. Use only a trusted LAN or VPN."
} else {
    Write-Output "Open http://127.0.0.1:6688"
}
